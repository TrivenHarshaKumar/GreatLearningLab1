package service;

import java.util.Random;

import employee.Employee;

public class CredentialService {
	
	public String CreateEmailId(Employee Emp)
	{		
		return Emp.getFirstName()+Emp.getLastName()+"@"+Emp.getDepartment()+"."+Emp.getOrganization()+".com";
	}
	
	public String CreatePassword()
	{
		Random rand = new Random();
		boolean Capital = false;
		boolean Small = false;
		boolean number =false;
		boolean SpecialChar =false;
		String Password ="";
		
		for(int i = 0; i< 8;i++)
		{
			if(!Small)
			{
				Password+= (char)(rand.nextInt(26)+'a');
			Small =true;
			}
			else if(!Capital)
			{
				Password+=  (char)(rand.nextInt(26)+'A');
				Capital =true;
			}
			else if(!number)
			{
				Password+= (char)(rand.nextInt(10)+'0');
				number =true;
			}
			else if(!SpecialChar)
			{
				Password+= (char)(rand.nextInt(15)+'!');
				SpecialChar =true;
			}
			else
			{
				Password+= (char)(rand.nextInt(93)+'!');
			}
		}
		
		return Password;
	}
}
