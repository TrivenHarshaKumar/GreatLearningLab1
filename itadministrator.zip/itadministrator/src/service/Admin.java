package service;

import java.util.Scanner;

import employee.Employee;

public class Admin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		System.out.println("Welcome to email ID and Password Generator");
		System.out.println("Please Enter your First Name : ");
		String FirstName =sc.nextLine();
		System.out.println("Please Enter your Last Name : ");
		String LastName =sc.nextLine();
		
		Employee Emp = new Employee(FirstName,LastName);
		
		System.out.println("Please choose your department::\r\n1)	Technical\r\n2)	Admin->adm\r\n3)	Human Resources\r\n4)	Legal\r\n");
		
		String Department = "";
		switch(sc.nextInt())
		{
		case 1:
			Department="tech";
			break;
		case 2:
			Department="adm";
			break;
		case 3:
			Department="hr";
			break;
		case 4:
			Department="lgl";
			break;
		}
		
		Emp.setDepartment(Department);
		CredentialService cs = new CredentialService();
		Emp.setEmailId(cs.CreateEmailId(Emp));
		Emp.setPassword(cs.CreatePassword());
		

		
		System.out.println("Dear "+Emp.getFirstName()+", your generated credentials are as follows\r\nEmail -->"+Emp.getEmailId()+"\r\nPassword -->"+Emp.getPassword());
		sc.close();
	}

}
